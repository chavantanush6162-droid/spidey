PRISMATIC ESPORTS — RAILWAY WEBSITE

1. Upload the contents of this project folder to a GitHub repository.
2. In Railway choose New Project > Deploy from GitHub Repo.
3. Select the repository. Railway will install dependencies using package.json.
4. In the Railway service settings, generate a public domain under Networking.

The website includes your supplied profile photo and Discord, Instagram, WhatsApp links. YouTube is not included. Replace the two text logo placeholders with your official Prismatic logo when available.
